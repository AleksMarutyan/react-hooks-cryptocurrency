import React from 'react';
import List from "./components/list/List";

const App = () =>{
    return(
        <div>
            <h2>App</h2>
            <List />
        </div>
    )
}
export default App;
